# phonegap-web-template
A website template for Adobe PhoneGap Build

- GitHub: https://github.com/pulipulichen/phonegap-web-template

----

# Customization Guide

- config.xml
- icon.png: Change your favicon. You can use [Iconshock](http://www.playpcesor.com/2017/09/iconshock-edit-icons.html) or [Icon Slayer](http://www.gieson.com/Library/projects/utilities/icon_slayer/).
- www/index.html: title, content, copyright, redirect URI

# Build you APP

- Adobe PhoneGap Build: https://build.phonegap.com/
- KeyStore for Android: http://blog.pulipuli.info/2015/07/phonegap-buildandroid-apk-how-to-build.html
-  